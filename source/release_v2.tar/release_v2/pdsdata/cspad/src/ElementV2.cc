#include "pdsdata/cspad/ElementV2.hh"

using namespace Pds::CsPad;

ElementV2::ElementV2() 
{
}
