#include "pdsdata/lusi/DiodeFexV1.hh"

using namespace Pds::Lusi;

DiodeFexV1::DiodeFexV1(float ch0) : value(ch0) {}
