#include "pdsdata/camera/FrameFccdConfigV1.hh"

#include <string.h>

using namespace Pds;
using namespace Camera;

FrameFccdConfigV1::FrameFccdConfigV1() {}

FrameFccdConfigV1::FrameFccdConfigV1(const FrameFccdConfigV1& c) {}
