#include "pdsdata/princeton/InfoV1.hh"

using namespace Pds;
using namespace Princeton;

InfoV1::InfoV1( float fTemperature ) :
 _fTemperature(fTemperature)
{
}

